const http = require("http");
const url = require("url");
const querystring = require("querystring");
var fs = require('fs')

const hostname = "127.0.0.1";
const port = 8500;

const server = http.createServer();

server.on("clientError", (err, socket) => {
  socket.end("HTTP/1.1 400 Bad Request\r\n\r\n");
});

server.on("request", (req, res) => {
  //   const { method, url, headers } = req;
  //   console.log(`url:${url}\nmethod:${method}\nheaders:${headers}`);
  var arg = url.parse(req.url).query;
  var params = querystring.parse(arg);

  const data = {
      jack:"i am jack",
      tom:"i am tom"
  }
  if (params.callback && params.callback == "dataHandle") {
    // fs.readFile('./js/remote.js',(err,data) =>{
    //     res.statusCode = 200;
    //     res.setHeader('Content-Type', 'text/html');
    //     if (!err) {
    //         res.end(data);
    //     }else {
    //         res.end('html not found');
    //     }
    // });  
    res.write(`dataHandle({"result":"${data[params.name]}"});`)   
    res.end()
    console.log(params.callback);
  }
});

server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
