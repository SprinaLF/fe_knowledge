const http = require("http");
const hostname = "127.0.0.1";
const port = 9000;

const whiteList = ['http://localhost:8081'];
const server = http.createServer();
server.on("clientError", (err, socket) => {
  socket.end("HTTP/1.1 400 Bad Request\r\n\r\n");
});
server.on("request", (req, res) => {
  const { method, url, headers } = req;
  console.log(`url:${url}\nmethod:${method}\nheaders:${headers.origin}`);
  if(whiteList.includes(req.headers.origin)){
    res.setHeader('Access-Control-Allow-Origin', req.headers.origin);
    res.setHeader('Access-Control-Allow-Methods', 'PUT, POST, GET, DELETE, OPTIONS');
  }
  res.write('A msg from server.')
  res.end()
});
server.listen(port, hostname, () => {
  console.log(`Server running at http://${hostname}:${port}/`);
});
